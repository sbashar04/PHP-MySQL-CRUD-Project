<?php
	session_start();
	if(isset($_GET["productid"])){
		require_once("server/connection.php");
		$productid = mysqli_real_escape_string($con, $_GET["productid"]);
		//Getting the image's extension.
		$sql = "SELECT image FROM products WHERE productid='".$productid."' LIMIT 1";
		$run = mysqli_query($con, $sql);
		$img_ext = mysqli_fetch_assoc($run);
		$img_ext = $img_ext["image"];
		//Img extension ends
		
		
		$sql = "DELETE FROM products WHERE productid='".$productid."' LIMIT 1";
		$run = mysqli_query($con, $sql);
		
		if($run == true){
			if(file_exists("./uploads/product{$productid}.{$img_ext}")){
				unlink("./uploads/product{$productid}.{$img_ext}");
			}
			$_SESSION["action_msg"] = "Product deleted.";
			header("location: display_product.php");
		}else{
			$_SESSION["action_msg"] = "Product was not deleted.";
			header("location: display_product.php");
		}
		
		
	}
?>