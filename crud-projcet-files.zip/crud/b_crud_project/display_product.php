<!doctype html>
<html lang="en">
<head>
    <title>Bootstrap CRUD Project</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css" />
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-info">
		<a class="navbar-brand" href="#">Bootstrap CRUD Project</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link active" href="#">Home <span class="sr-only">(current)</span></a>
				</li>
				<li>
					<a class="nav-link" href="add_product.php">Add Product <span class="sr-only">(current)</span></a>
				</li>
			</ul>
		</div>
	</nav>
	
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h1>All products</h1>
					<?php
						session_start();
						if(isset($_SESSION["action_msg"])){
							echo '<p class="text-success bg-warning">'.$_SESSION["action_msg"].'</p>';
							$_SESSION["action_msg"] = "";
						}
					?>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
					<table class="table table-hover table-stripped">
						<thead>
							<tr>
								<th>ID</th>
								<th>Name</th>
								<th>Category</th>
								<th>Image</th>
								<th>Price</th>
								<th>Stock</th>
								<th>Delivery</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php
								$sql = "SELECT * FROM products";
								require_once("server/connection.php");
								$run = mysqli_query($con, $sql);
								
								while($ep = mysqli_fetch_assoc($run)){
							?>
							<tr>
								<td><?php echo $ep["productid"];?></td>
								<td><?php echo substr($ep["title"], 0, 40)."...";?></td>
								<td>
									<?php
										$categories = array(
											"1" => "Men's Clothing",
											"2" => "Women's Clothing",
											"3" => "Baby's Clothing",
											"4" => "Sportswear"
										);
										
										echo $categories[$ep["category"]];
									
									?>
								</td>
								<td>
									<img src="uploads/product<?php echo $ep["productid"].'.'.$ep["image"];?>" alt="<?php echo $ep["title"];?>" width="50" height="50" />
								</td>
								<td>TK. <?php echo $ep["price"];?></td>
								<td><?php echo $ep["stock"];?></td>
								<td>
									<?php 
										$deliveryoptions = array(
											"1" => "Cash on Delivery",
											"2" => "Free Delivery",
											"3" => "Store Pick Up"
										);
										$do = $ep["deliveryoption"];
										$do = explode(", ", $do);
										$dot = "";
										for($i = 0; $i < count($do); $i++){
											$dot .= $deliveryoptions[$do[$i]];
											if($i < count($do)-1){
												$dot .= ",<br>";
											}
										}
										echo $dot;
									?>
								</td>
								<td>
									<a href="edit_product.php?productid=<?php echo $ep["productid"];?>" class="btn btn-sm btn-info">Edit</a>
									<a href="delete_product.php?productid=<?php echo $ep["productid"];?>" class="btn btn-sm btn-danger">Delete</a>
								</td>
							</tr>
								<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	
	<div class="footer bg-info">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<p>&copy; All rights reserved.</p>
				</div>
			</div>
		</div>
	</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="assets/js/jquery.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="assets/js/popper.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <script src="assets/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
</body>
</html>