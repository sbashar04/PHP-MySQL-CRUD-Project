<?php
	session_start();
	if(isset($_POST["addpro"])){
		$title = $_POST["title"];
		$category = $_POST["category"];
		$image = $_FILES["pr_image"];
		$price = $_POST["price"];
		$stock = $_POST["stock"];
		$delivery = $_POST["delivery"];//Array
		
		//Get extension
		$ext = pathinfo($image["name"]);
		$ext = strtolower($ext["extension"]);
		
		if($ext != "jpg" && $ext != "jpeg" && $ext != "png"){
			$ext = "";
		}
		
		//Delivery
		$db_deliver = "";
		$c = 0;
		foreach($delivery as $d){
			$c++;
			$db_deliver .= $d;
			
			if($c < count($delivery)){
				$db_deliver .= ", ";
			}
		}
		
		require_once("connection.php");
		date_default_timezone_set("Asia/Dhaka");
		$created = date("Y-m-d h:i a");
		
		$sql = "INSERT INTO products(title, category, image, price, stock, deliveryoption, created) VALUES('".$title."', '".$category."', '".$ext."', '".$price."', '".$stock."', '".$db_deliver."', '".$created."')";
		//echo $sql; die;
		$run = mysqli_query($con, $sql);//True or false;
		
		if($run){
			$id = mysqli_insert_id($con);
			if($ext){
				move_uploaded_file($image["tmp_name"], "../uploads/product{$id}.{$ext}");
			}
			$_SESSION["action_msg"] = "Product created.";
			header("location: ../display_product.php");
		}else{
			$_SESSION["action_msg"] = "Product was not created.";
			header("location: ../display_product.php");
		}
		
	}
?>