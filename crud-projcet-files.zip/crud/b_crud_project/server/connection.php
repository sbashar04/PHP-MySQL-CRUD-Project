<?php
	$con = mysqli_connect("localhost", "root", "", "crud_project");
?>