<?php
	session_start();
	if(isset($_POST["updatepro"])){
		$productid = $_POST["productid"];
		$title = $_POST["title"];
		$category = $_POST["category"];
		$image = $_FILES["pr_image"];
		$price = $_POST["price"];
		$stock = $_POST["stock"];
		$delivery = array();
		if(isset($_POST["delivery"])){
			$delivery = $_POST["delivery"];//Array
		}
		
		//Get extension
		$ext = "";
		if($image["name"]){
			$ext = pathinfo($image["name"]);
			$ext = strtolower($ext["extension"]);
			
			if($ext != "jpg" && $ext != "jpeg" && $ext != "png"){
				$ext = "";
			}
		}
		
		//Delivery
		$db_deliver = "";
		$c = 0;
		foreach($delivery as $d){
			$c++;
			$db_deliver .= $d;
			
			if($c < count($delivery)){
				$db_deliver .= ", ";
			}
		}
		
		require_once("connection.php");
		
		//For getting image extension before updating the data.
		$sql = "SELECT image FROM products WHERE productid='".$productid."' LIMIT 1";
		$run = mysqli_query($con, $sql);
		$img_ext = mysqli_fetch_assoc($run);
		$img_ext = $img_ext["image"];
		
		
		$sql = "UPDATE products SET title='".$title."', category='".$category."', image='".$ext."', price='".$price."', stock='".$stock."', deliveryoption='".$db_deliver."' WHERE productid='".$productid."'";
		// echo $sql; die;
		$run = mysqli_query($con, $sql);//True or false;
		
		if($run){
			if($ext){
				if(file_exists("./uploads/product{$productid}.{$img_ext}")){
					unlink("./uploads/product{$productid}.{$img_ext}");
				}
				move_uploaded_file($image["tmp_name"], "../uploads/product{$productid}.{$ext}");
			}
			$_SESSION["action_msg"] = "Product updated.";
			header("location: ../display_product.php");
		}else{
			$_SESSION["action_msg"] = "Product was not updated.";
			header("location: ../display_product.php");
		}
		
	}
?>