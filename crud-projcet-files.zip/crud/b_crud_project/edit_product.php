<!doctype html>
<html lang="en">
<head>
    <title>Bootstrap CRUD Project</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
	<link rel="stylesheet" href="style.css" />
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-info">
		<a class="navbar-brand" href="#">Bootstrap CRUD Project</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link" href="display_product.php">Home <span class="sr-only">(current)</span></a>
				</li>
			</ul>
		</div>
	</nav>
	
	<div class="content">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h1>Add a new product</h1>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-12">
					<?php
						if(isset($_GET["productid"])){
							$productid = $_GET["productid"];
						}
						require_once("server/connection.php");
						$sql = "SELECT * FROM products WHERE productid='".$productid."' LIMIT 1";
						$run = mysqli_query($con, $sql);
						$product = mysqli_fetch_assoc($run);
						
					?>
					<form action="server/update_product.php" method="post" class="form-horizontal" enctype="multipart/form-data">
						<input type="hidden" name="productid" value="<?php echo $product["productid"];?>" />
						<div class="form-group">
							<label for="title">Title</label>
							<input type="text" name="title" id="title" class="form-control" maxlength="95" value="<?php echo $product["title"];?>" />
						</div>
						<div class="form-group">
							<label for="category">Category</label>
							<select name="category" class="form-control">
								<option value="">Choose one</option>
								<option value="1" <?php if($product["category"]==1){echo " selected ";} ?> >Men's Clothing</option>
								<option value="2" <?php if($product["category"]==2){echo " selected ";} ?> >Women's Clothing</option>
								<option value="3" <?php if($product["category"]==3){echo " selected ";} ?> >Baby's Clothing</option>
								<option value="4" <?php if($product["category"]==4){echo " selected ";} ?> >Sportswear</option>
							</select>
						</div>
						<div class="form-group">
							<label for="title">Image</label><br>
							<input type="file" name="pr_image" /><br>
							<img src="uploads/product<?php echo $product["productid"].'.'.$product["image"];?>" alt="<?php echo $product["title"];?>" width="100" height="100" />
						</div>
						<div class="form-group">
							<label for="title">Price</label>
							<input type="number" name="price" id="price" class="form-control" value="<?php echo $product["price"];?>" />
						</div>
						<div class="form-group">
							<label for="title">Stock</label>
							<input type="number" name="stock" id="stock" class="form-control" value="<?php echo $product["stock"];?>" />
						</div>
						<div class="form-group">
							<?php
								$do = explode(", ", $product["deliveryoption"]);
							?>
							<label for="deliveryoptions">Delivery option:</label><br>
							
							
							<label for="cashondelivery"><input type="checkbox" name="delivery[]" id="cashondelivery" value="1" <?php for($i=0; $i<count($do);$i++){if($do[$i] == 1){echo " checked ";} } ?> /> Cash on delivery</label><br>
			
							
							<label for="freedelivery"><input type="checkbox" name="delivery[]" id="freedelivery" value="2" <?php for($i=0; $i<count($do);$i++){if($do[$i] == 2){echo " checked ";} } ?> /> Free delivery</label><br>
							
							<label for="Storepickup"><input type="checkbox" name="delivery[]" id="Storepickup" value="3" <?php for($i=0; $i<count($do);$i++){if($do[$i] == 3){echo " checked ";} } ?> /> Store pick up</label>
						</div>
						
						<input type="submit" value="Update Product" name="updatepro" class="btn btn-success" />
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<div class="footer bg-info">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<p>&copy; All rights reserved.</p>
				</div>
			</div>
		</div>
	</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="assets/js/jquery.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="assets/js/popper.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    <script src="assets/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
</body>
</html>