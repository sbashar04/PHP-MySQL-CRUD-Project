-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2017 at 07:01 AM
-- Server version: 5.7.11
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `productid` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `category` int(11) NOT NULL,
  `image` varchar(4) NOT NULL,
  `price` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `deliveryoption` varchar(15) NOT NULL,
  `created` varchar(22) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productid`, `title`, `category`, `image`, `price`, `stock`, `deliveryoption`, `created`) VALUES
(13, 'Nihil repellendus Pariatur Magna', 1, '', 82, 86, '1', '2017-12-04 11:41 am'),
(12, 'Sequi distinctio Voluptatum', 2, '', 22, 44, '2', '2017-12-04 11:41 am'),
(11, 'Facere accusantium id voluptate omnis veniam accusantium', 2, 'jpg', 297, 34, '3', '2017-12-04 11:41 am'),
(10, 'Dolores minima doloribus quas enim mollitia qui id adipisicing facilis excepteur nobis', 4, '', 851, 60, '1', '2017-12-04 11:41 am'),
(9, 'Commodo explicabo Sint eos optio rerum explicabo Fugit necessitatibus sit ut possimus of', 2, 'jpg', 821, 64, '1, 2', '2017-12-04 11:41 am'),
(14, 'Excepteur est velit irure magnam incidunt voluptatibus et alias id', 4, '', 435, 19, '1, 3', '2017-12-04 11:42 am');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`productid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `productid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
